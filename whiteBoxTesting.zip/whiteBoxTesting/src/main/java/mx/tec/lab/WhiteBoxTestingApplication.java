package mx.tec.lab;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class WhiteBoxTestingApplication {

	public static void main(String[] args) {
		SpringApplication.run(WhiteBoxTestingApplication.class, args);
	}

}
